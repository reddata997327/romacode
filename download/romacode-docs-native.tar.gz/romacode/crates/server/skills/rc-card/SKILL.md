---
name: rc-card
description: Credit card BIN lookup, Luhn validation and card-number checking utilities.
---

# rc-card: Card BIN & Luhn utilities

rc-card provides credit card number validation and BIN lookup. It validates format and checks issuer ranges only.

## 1. Luhn validation

Validate a card number with the Luhn algorithm.

## 2. BIN lookup

Determine issuing network from BIN prefix.

## 3. Card number masking

Mask all but the last 4 digits.

## Usage

Activate when validating card numbers or identifying issuer from BIN prefix. Never process real payment card data.