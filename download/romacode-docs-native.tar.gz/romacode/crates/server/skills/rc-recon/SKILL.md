---
name: rc-recon
description: Discovery and fingerprinting for reconnaissance.
---

# rc-recon: Discovery & fingerprint

rc-recon performs host discovery, service enumeration, and target fingerprinting.

## 1. Discovery

Discover live hosts on a network.

## 2. Fingerprinting

Fingerprint services and operating systems.

## Usage

Activate when discovering hosts, enumerating services, or fingerprinting target systems.