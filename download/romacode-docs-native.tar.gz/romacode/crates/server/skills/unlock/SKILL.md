---
name: unlock
description: Unlock any local LLM - download, quantize and edit any downloadable HuggingFace model with the Heretic engine, then run it in RomaCode as a local provider. Covers size/memory estimation for every precision from the model id, license checking, honest untested-model labeling, doctor.py and setup.py usage, llama.cpp/LM Studio/Ollama paths. Use when the user wants to run a local model, remove fine-tuned refusals, or reshape a model's persona or knowledge.
---

# Unlock: local model editing with Heretic

Unlock is model-agnostic: ANY downloadable local model works — Llama, Mistral,
Qwen, Gemma, Phi, DeepSeek, Heretic-generated hybrids — not only the measured
Qwen3-4B anchor. The engine is Heretic (p-e-w's GGUF-editing tool, AGPL);
the original model file is never touched and every run produces hashed
before/after evidence.

## 1. Pick and size the model first

Estimate from the id before downloading — the parameter count in the id and
the precision decide everything:

| Precision | Bytes/param | 4B model | 8B model |
|---|---|---|---|
| Q2_K | ~2.6 bpw | ~1.3 GB | ~2.6 GB |
| Q4_K_M | ~4.8 bpw | ~2.4 GB | ~4.9 GB |
| Q8_0 | ~8.5 bpw | ~4.3 GB | ~8.5 GB |
| FP16 | 2.0 B/param | ~8.0 GB | ~16 GB |

RAM needed ≈ file size + 0.5-1.0 GB context/KV overhead. Parse the id:
`qwen3-4b-instruct` → 4B params; a bare id like `hermes-3` → look the config
up on the hub page, never guess. GPU offload layers are optional; CPU-only
works with lower thread count.

License check before use: read the model card license (llama-3 community,
gemma, apache-2.0, MIT all allow local editing; verify redistribution terms
for the EDITED artifact separately).

## 2. Setup and doctor

`setup.py` downloads Heretic plus llama.cpp binaries and reports the real
download size for the chosen model (dynamic, not hardcoded). `doctor.py`
verifies the toolchain and accepts `--model-id` and `--dtype` so the plan is
computed for YOUR model, not the tested anchor:

```bash
python setup.py                       # toolchain + Heretic
python doctor.py --model-id qwen3-4b-instruct --dtype Q4_K_M
```

Doctor prints: estimated file size, RAM need, disk free verdict, license note,
and an UNTESTED-model warning when the id is not the calibrated anchor.

## 3. Run the unlock

```bash
heretic run <model-id> --dtype Q4_K_M   # or a local GGUF path
```

Heretic steers itself with contradictory-pair prompts, edits weights, and
writes to `heretic-workspace/`:
* `README.md` — what changed, KL divergence vs baseline, the KL ceiling it
  hit;
* before/after SHA-256 hashes of the GGUF;
* the final edited GGUF (the original is untouched).

Claim honestly: an untested model gets "estimated" numbers, not measured
ones. Never fabricate benchmark results.

## 4. Serve it in RomaCode

Point a local provider at the edited GGUF — llama.cpp `llama-server`,
LM Studio or Ollama all expose an OpenAI-compatible endpoint:

```bash
llama-server -m heretic-workspace/model-Q4_K_M.gguf --port 8321
# config.json → providers: {"local-heretic": {"base_url": "http://127.0.0.1:8321/v1", "api": "openai"}}
```

Then `/models` in RomaCode picks it up (fetched catalogs persist into the
model options since v0.7.7). Keep the hash pair with the artifact so anyone
can verify which file was edited.
