---
name: rc-forge
description: Dropper, loader, and APK weaponisation tooling.
---

# rc-forge: Dropper, loader & APK weaponisation

rc-forge builds droppers, loaders, and weaponised Android APKs.

## 1. Dropper

Build droppers that deliver payloads.

## 2. Loader

Build loaders that execute payloads in memory.

## 3. APK weaponisation

Weaponise Android APKs for target deployment.

## Usage

Activate when building droppers, loaders, or weaponised APKs.