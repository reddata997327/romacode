---
name: rc-creds
description: Credential capture, spray and sweep operations.
---

# rc-creds: Credential capture, spray & sweep

rc-creds manages credential operations: capture discovered credentials, spray password lists against targets, and sweep harvested credentials for reuse.

## 1. Capture

Record discovered credentials into the loot ledger with evidence hashes.

## 2. Spray

Password spraying: attempt a small set of common passwords against many accounts.

## 3. Sweep

Sweep: test harvested credentials across multiple hosts/services.

## Usage

Activate when managing credential discovery, password spraying, or credential sweep across hosts.