---
name: documents
description: Overview of the built-in pure-Rust documents engine — when to reach for docx_*, xlsx_*, pptx_*, pdf_*, chart_render, canvas_design and figma_* tools instead of shelling out to Python or Office. Covers the shared JSON conventions (paths, dates, formulas, color strings) and the verify-after-write workflow.
---

# Documents Engine (rc-docs, builtin native)

RomaCode ships a complete document toolchain **in the binary itself**: Word,
Excel, PowerPoint, PDF, data charts, canvas design and the Figma REST client
— all pure Rust, no Python, no LibreOffice, no external binaries. Prefer
these tools over Bash + scripts for anything document-shaped; they are
deterministic, offline and structured.

## Tool map

| Task | Tools |
|---|---|
| Word reports / letters | `docx_create`, `docx_read` |
| Excel workbooks, CSV | `xlsx_create`, `xlsx_read`, `xlsx_edit`, `xlsx_convert` |
| PowerPoint decks | `pptx_create`, `pptx_read` |
| PDF reports, merge, split | `pdf_create`, `pdf_read`, `pdf_merge`, `pdf_split` |
| Data charts (PNG + SVG) | `chart_render` (13 types) |
| Posters, cards, social art | `canvas_design` (PNG + PDF export) |
| Figma files, nodes, images, comments | `figma_file`, `figma_node`, `figma_images`, `figma_comments`, `figma_me` |
| Diagnostics | `documents_status` (fonts, version, Figma token) |

## Shared conventions

* **Paths** are relative to the project root (or absolute). Missing parent
  directories are created.
* **Dates** in xlsx cells: the string `"date:2024-01-05"` or
  `{"date": "2024-01-05"}` stores a real Excel date serial.
* **Formulas**: any cell string starting with `=` (e.g. `"=SUM(A1:A9)"`);
  `xlsx_read` reports both the formula and its cached value.
* **Colors** are hex (`#1F77B4`) or CSS-ish names (`steelblue`).
* **Inline markup** in docx text: `**bold**`, `*italic*`, `__underline__`,
  `` `code` ``.
* **Output caps**: tool output is capped (`documents.max_output_chars`,
  default 40k chars) — reads of huge workbooks come back truncated with a
  note rather than flooding the context.

## Workflow (every deliverable)

1. Create with the `*_create` tool in one call.
2. **Verify by reading back** with the matching `*_read` tool — check counts,
   headings, table shapes; search your own output for `TODO`/`XXX`.
3. Fix at the source (regenerate the file) — never hand-patch.

## Enable / disable

The engine is on by default. `/documents on|off` toggles it, `/documents
status` prints the doctor (engine version, tool list, discovered fonts,
Figma token presence). Fonts for PDF/chart/canvas text are discovered from
the system (Noto CJK first); `RC_DOCS_FONT=/path/to.ttf` overrides.

Skills with per-format recipes: `docx-toolkit`, `xlsx-toolkit`,
`pptx-toolkit`, `pdf-toolkit`, `charts-toolkit`, `canvas-design`,
`figma-toolkit`.
