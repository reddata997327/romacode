---
name: xlsx-toolkit
description: Recipes for Excel with the native xlsx_create/xlsx_read/xlsx_edit/xlsx_convert tools — typed cells, formulas, dates, bold headers with fill, freeze panes, autofilter, merged cells, CSV conversion and in-place patching that preserves every other zip part. Use for any spreadsheet deliverable.
---

# Excel Toolkit (xlsx_*)

## Create — one call, multi-sheet

```json
{"path": "report.xlsx", "sheets": [
  {"name": "Data", "rows": [["Item", "Qty", "When"],
                             ["Widget", 12, "date:2024-01-05"]],
   "widths": {"A": 24, "B": 10},
   "freeze_top": true, "autofilter": "A1:C2",
   "merges": ["A1:C1"]},
  {"name": "Calc", "cells": {"B1": "=Data!B2*2", "B2": {"formula": "B1+1", "value": 25}}}
]}
```

* Typed cells: strings stay text, numbers auto-type, `"=…"` becomes a
  formula, `"date:YYYY-MM-DD"` a real date serial.
* First row gets a bold header style with a blue fill automatically
  (`header_style: false` to disable).
* `rows` fills A1 rightward/downward; `cells` targets explicit refs; both
  can mix.

## Read

`xlsx_read` returns every sheet's grid: values, `type` (text/number/bool/
date/formula/error) and `formula` per cell. Cap output with `max_chars`.

## Edit in place (formatting-preserving)

`xlsx_edit` rewrites **only the target sheet's XML** — styles, charts,
images and every other part survive byte-identical:

```json
{"path": "book.xlsx", "sheet": "Data", "cells": {"B2": 42, "C3": "done", "D4": "=SUM(B2:B3)", "E5": null}}
```

`null` deletes the cell. Edited cells keep their original style index.

## CSV

* `xlsx_convert action=csv_to_xlsx` — CSV text → workbook (numbers
  auto-typed, first row header; `delimiter` option).
* `xlsx_convert action=xlsx_to_csv` — workbook → CSV text (sheet option).

## Verify

`xlsx_read` after every write: expected row/cell values, date cells come
back as `YYYY-MM-DD`, formulas reported. Regenerate on mismatch.
