---
name: pdf-toolkit
description: Recipes for PDF with the native pdf_create/pdf_read/pdf_merge/pdf_split tools — CJK-capable embedded TrueType fonts, cover pages, headings, justified text, striped tables, images, page numbers, lossless merge/split. Use for any PDF deliverable.
---

# PDF Toolkit (pdf_*)

## Create reports — one call

```json
{"path": "report.pdf", "page_size": "a4", "accent": "#1F3864",
 "title": "Q4 Report", "author": "Finance",
 "blocks": [
   {"type": "cover", "title": "Q4 Report", "subtitle": "Finance team",
    "author": "Ada", "date": "2024-01-05", "accent": "#1F3864"},
   {"type": "h1", "text": "Overview"},
   {"type": "p", "text": "3-5 sentences per paragraph…"},
   {"type": "table", "header": ["Metric", "Q3", "Q4"], "rows": [["Revenue", "1.2M", "1.4M"]], "widths": [2, 1, 1]},
   {"type": "image", "path": "chart.png", "width_pt": 300, "caption": "Figure 1"},
   {"type": "bullets", "items": ["…"]}, {"type": "rule"}, {"type": "pagebreak"}
 ]}
```

* Blocks: cover, h1–h4, p (align left/center/right/justify, size_pt, color,
  line_spacing), bullets, numbered, table (relative `widths`, blue header,
  striped rows, wraps inside cells), image (png decoded / jpeg passthrough,
  aspect preserved), rule, spacer, pagebreak.
* Fonts: system TrueType embedded with Identity-H + ToUnicode — **CJK
  renders correctly** and text stays extractable/copyable. `RC_DOCS_FONT`
  overrides font discovery. Page numbers: "Page N of M" footer by default.

## Read

`pdf_read` → page count, page sizes, title/author/producer metadata and
best-effort text extraction (FlateDecode + ToUnicode + UTF-16 strings).
Scanned/image PDFs report honestly that no text was decoded.

## Merge & split (lossless)

* `pdf_merge {"paths": ["a.pdf", "b.pdf"], "out": "ab.pdf"}` — object-graph
  rewrite keeps fonts, images and resources per page; mixed page sizes OK.
* `pdf_split {"path": "in.pdf", "from": 2, "to": 4, "out": "part.pdf"}` —
  1-based inclusive range.

## Verify

`pdf_read` after writing: page count, title metadata, extracted text
contains your headings. Regenerate on mismatch.
