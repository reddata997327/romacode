---
name: rc-pivot
description: Tunnel and SOCKS manager for network pivoting.
---

# rc-pivot: Tunnel & SOCKS manager

rc-pivot manages network tunnels and SOCKS proxies for pivoting.

## 1. Tunnel management

Establish and manage network tunnels.

## 2. SOCKS proxy

Run SOCKS proxies for traffic redirection through pivot hosts.

## Usage

Activate when establishing tunnels, SOCKS proxies, or pivoting.