---
name: figma-toolkit
description: Figma access with the built-in REST client — figma_file/figma_node for file and node trees, figma_images to render nodes to PNG/SVG, figma_comments to read/post comments, figma_me to verify the token. Use when the user mentions Figma designs, hand-off, or asset export.
---

# Figma Toolkit (figma_*)

The brain talks to `api.figma.com` directly (rustls, no MCP server). Auth:
`FIGMA_TOKEN` in the server environment (or `token` in the call).

1. **Get the file key** — from a URL like
   `figma.com/file/<KEY>/Name`, or ask the user.
2. **Survey**: `figma_file {"key": "…"}` returns name, lastModified,
   thumbnail and the page tree trimmed to `depth` levels (ids, names,
   types, fills, text `characters`). Depth 3–4 is usually right; go deeper
   with `figma_node {"key": "…", "ids": "12:34,12:35"}`.
3. **Export assets**: `figma_images {"key": "…", "ids": "12:34",
   "format": "png", "scale": 2, "dir": "assets/"}` renders nodes and
   downloads them into the project; use `format: "svg"` for vectors/icons.
4. **Comments**: `figma_comments {"key": "…"}` lists them;
   `{"key": "…", "message": "…"} ` posts one.
5. **Sanity**: `figma_me` verifies the token and prints the user.

## Hand-off recipes

* **Design → code**: file survey → `figma_node` on the target frames → read
  fills/sizes/text → implement (colors/sizes are in the node JSON).
* **Asset pipeline**: pick node ids (icons/logos) → `figma_images`
  scale 2 PNG + SVG → embed via `docx_create`/`pptx_create`/`canvas_design`.
* **Review loop**: `figma_comments` to read feedback, act, then post a
  reply comment.

Failures are honest: missing token → "set FIGMA_TOKEN"; bad key → API 404
with the message surfaced. Do not retry blindly — check the key and token
first.
