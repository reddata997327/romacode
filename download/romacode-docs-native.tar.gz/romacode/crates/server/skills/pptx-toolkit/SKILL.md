---
name: pptx-toolkit
description: Recipes for PowerPoint with the native pptx_create/pptx_read tools — themed 16:9 decks (title, section, bullets, two-content, image, blank slides), speaker notes, accent-color theming. Use for any .pptx deliverable.
---

# PowerPoint Toolkit (pptx_create / pptx_read)

One `pptx_create` call builds a complete deck (master, layouts, theme and
notes included — opens cleanly in PowerPoint, Keynote and LibreOffice).

## Slide kinds

| type | fields |
|---|---|
| title | `title`, `subtitle` (hero layout + accent bar) |
| section | `title` (big accent text) |
| bullets | `title`, `items` (string or `{text, level}`), `notes` |
| two_content | `title`, `left[]`, `right[]` |
| image | `title`, `path` (png/jpg), `caption`, `notes` |
| blank | `text` |

Global: `title`, `author`, `accent1`..`accent6` hex colors (default
Office-blue palette). Speaker `notes` on any slide create real notes slides.

## Recipes

**Pitch deck**: title → section → bullets ×3 → image slide (chart PNG from
`chart_render`) → two_content comparison → section close. Keep ≤6 bullets
per slide, ≤12 words per bullet.

**Training deck**: section per module, bullets with `level:1` sub-points,
`notes` carrying the talk track.

**Data review**: build charts first with `chart_render` (PNG), then image
slides with captions; `two_content` for chart + takeaways.

## Verify

`pptx_read` returns slide count, per-slide text and notes. Check slide
count matches the plan and no slide is text-empty. Regenerate to fix.
