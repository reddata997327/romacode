---
name: rc-launder
description: Hop and custody modelling for asset laundering.
---

# rc-launder: Hop & custody modelling

rc-launder models hop chains and custody tracking for asset laundering operations.

## 1. Hop modelling

Model intermediary hops between source and destination.

## 2. Custody tracking

Track custody of assets through each hop.

## Usage

Activate when modelling hops, custody chains, or laundering paths.