---
name: romacode-tool-recipes
description: Step-by-step recipes and verified code skeletons for every RomaCode tool surface - the 21 registered brain tools (Read, Edit, Bash, web_fetch, skill, rnmap_scan, browser, rag_index, rag_search, webapp_scaffold, webapp_check, android_setup and the android_* device family), the rc-* framework tools not yet merged, and how to add a new tool to the registry so both the native loop and the langchain engine can call it.
---

# Tool Recipes - Code Skeletons

All skeletons are verified against the tree (romacode-fixed-v3). Shape sources:
`crates/server/src/tools/webfetch.rs` (definition + execute), `tools/mod.rs`
(registration + dispatch), `crates/rc-tools/rc-core/src/tool.rs` (rc contract).

## A. Brain tool (the next registered tool)

### `crates/server/src/tools/mytool.rs`

```rust
//! One-line purpose. Keep the description model-facing and specific.

use crate::config::Config;
use serde_json::{json, Value};
use std::sync::atomic::{AtomicBool, Ordering};

/// Anthropic-shaped definition; tools/mod.rs wraps it for OpenAI providers.
pub fn definition() -> Value {
    json!({
        "name": "mytool",
        "description": "What it does, when to use it, what it returns.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path":  { "type": "string", "description": "..." },
                "limit": { "type": "integer", "description": "..." }
            },
            "required": ["path"]
        }
    })
}

pub fn execute(cfg: &Config, input: &Value, cancel: &AtomicBool) -> Result<String, String> {
    if cancel.load(Ordering::SeqCst) {
        return Err("cancelled".into());
    }
    let path = input.get("path").and_then(|v| v.as_str())
        .ok_or("missing 'path'")?;
    // ... real work; poll cancel in loops; cap output chars;
    // Err(String) is user-facing: explain policy/bad input, never panic.
    Ok(format!("done: {path}"))
}
```

### Register in `crates/server/src/tools/mod.rs`

```rust
pub mod mytool;

// inside definitions(): BOTH branches
if cfg.mytool.enabled { defs.push(mytool::definition()); }          // anthropic arm
if cfg.mytool.enabled { defs.push(wrap(mytool::definition())); }    // openai arm

// inside execute():
"mytool" => mytool::execute(cfg, input, cancel),
```

### Config section (config.rs + config.example.json)

Follow the `rnmap` pattern: a serde struct with `Default` + clamps in
`config.rs` (`Default::default()`, `apply_clamps`), a matching block in
`config.example.json`, and an `/mytool on|off` arm in `Hub::run_command` if the tool
is toggleable.

### Tests

- Unit tests next to `execute` (input shapes, caps, cancel).
- If the tool touches sessions/events: an `api.rs` test like
  `approval_flow_end_to_end_through_the_hub`.
- rnmap keeps 15 engine tests including a real local scan - imitate that depth for
  anything process-spawning.

## B. rc-* tool (framework side, not the brain)

### Rust (rc-core contract)

```rust
use rc_core::tool::{Tool, ToolContext, ToolArc};
use rc_core::schema::Schema;
use rc_core::error::ToolResult;
use async_trait::async_trait;
use serde_json::Value;

struct Upper;

#[async_trait]
impl Tool for Upper {
    fn name(&self) -> &str { "upper" }
    fn description(&self) -> &str { "Uppercase the input text" }
    fn schema(&self) -> Schema { /* params: text: Text (required) */ }
    async fn run(&self, input: &Value, ctx: &ToolContext) -> ToolResult<String> {
        // ctx: correlation_id, timeout_ms, live cancel flag (Arc<AtomicBool>),
        // allow_net, allow_fs_paths - self-check before I/O.
    }
}
// Register: Registry::new().register_all(vec![arc]) or ship via rc-builtin's
// category all() pattern (see rc-builtin/src/text.rs).
```

- Composition: wrap steps with rc-compose primitives (pipeline, parallel, branch,
  dag, iter); composed tools report `ToolSourceKind::Compose(kind)` and inherit the
  live cancel flag.
- Import paths: declarative YAML/JSON -> ShellTool; REST/OpenAPI -> HttpTool
  (`shell_quote` for any shell interpolation); MCP `tools/list` -> mcp source.
- Lifecycle: `rc_lifecycle::Lifecycle` walks a `SourceRegistry`:
  discover -> register -> validate -> load -> execute (timed, monitored).
- Python mirror: same contract in `rc-python/rc_python/` (core, schema, validator,
  registry, executor, sandbox, permissions, manifest, lifecycle, compose, sources).

## C. Slash command skeleton

Server (`api.rs`, `Hub::run_command`):

```rust
"mysetting" if arg.is_empty() => format!("My setting: {}", cfg.mytool.enabled),
"mysetting" => match arg.to_ascii_lowercase().as_str() {
    "on" | "off" => { cfg.mytool.enabled = arg == "on"; cfg.save();
                      format!("My tool {}.", if arg == "on" {"enabled"} else {"disabled"}) }
    other => format!("unknown value '{other}' - use /mysetting on or off"),
},
```

Client (`client-tui/src/app.rs`, `send()` ~line 569) - add to the whitelist:

```rust
"providers" | "provider" | ... | "prefs" | "mysetting" => (),
```

Missing this step sends the text to the model as a normal message (this is exactly
the current `/rnmap` / `/settings` gap).

## D. Provider row skeleton (`shared/src/catalog.rs`)

```rust
Known {
    id: "myvendor",
    name: "MyVendor",
    kind: ApiKind::OpenAi,            // or ApiKind::Anthropic
    base_url: "https://...",          // omitted from the report per policy
    key_env: "MYVENDOR_API_KEY",
    needs_key: true,                  // false for local servers (ollama, lmstudio)
    default_model: "vendor-default",
    models: &["vendor-default", "vendor-large"],
},
```
