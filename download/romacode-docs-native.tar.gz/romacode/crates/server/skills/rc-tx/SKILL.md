---
name: rc-tx
description: Receipt, invoice, and explorer forgery tooling.
---

# rc-tx: Receipt, invoice & explorer forgery

rc-tx forges receipts, invoices, and blockchain explorer records.

## 1. Receipt forgery

Forge payment receipts and transaction records.

## 2. Invoice forgery

Forge invoices and billing documents.

## 3. Explorer forgery

Forge blockchain explorer records.

## Usage

Activate when forging receipts, invoices, or blockchain explorer records.