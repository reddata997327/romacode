---
name: charts-toolkit
description: Data charts with the native chart_render tool — 13 types (line, area, bar, hbar, stacked_bar, pie, donut, scatter, histogram, heatmap, radar, waterfall, boxplot) rendered to PNG plus an SVG twin by the built-in pure-Rust rasterizer. Use whenever a chart is asked for or a document needs a figure.
---

# Charts Toolkit (chart_render)

Pure-Rust rasterizer, PNG output (+ optional SVG twin), CJK-capable text
from system fonts, no plotting binaries.

## Examples

```json
{"type": "bar", "title": "Revenue by quarter", "labels": ["Q1", "Q2", "Q3", "Q4"],
 "series": [{"name": "2023", "values": [12, 18, 15, 22]}, {"name": "2024", "values": [14, 21, 19, 26]}],
 "y_label": "M USD", "out_png": "revenue.png", "out_svg": "revenue.svg"}

{"type": "pie", "labels": ["Direct", "Partner", "Other"],
 "series": [{"values": [60, 30, 10]}], "legend": true, "out_png": "mix.png"}

{"type": "scatter", "series": [{"name": "p", "points": [[1, 2], [2, 4], [3, 3]]}], "out_png": "xy.png"}
```

## Types & knobs

line, area, bar, hbar, stacked_bar (`"stacked": true`), pie, donut,
scatter (`points: [[x,y],…]`), histogram (`bins`), heatmap (series = rows),
radar (`labels` = spokes), waterfall (deltas, total highlighted), boxplot
(series = distributions). Size `width`/`height` (default 800×500),
`legend` on/off, custom `palette` of hex colors.

## Rules of thumb

* Line for trends over time; bar for category comparison; hbar for many
  categories or long labels; pie/donut only for ≤5 slices; scatter for
  correlation; histogram for distribution shape; boxplot for spread
  outliers; waterfall for bridge/variance stories; radar for multi-metric
  profiles (≤8 spokes); heatmap for matrix data.
* One message per chart: kill series that do not support it.
* For documents: render the PNG, then embed it (`docx_create` image block,
  `pdf_create` image block, `pptx_create` image slide). The SVG twin is
  for web/embedded use.
* Verify: the tool returns `png_bytes` + dimensions — a path without bytes
  means it failed; fix the input, not the file.
