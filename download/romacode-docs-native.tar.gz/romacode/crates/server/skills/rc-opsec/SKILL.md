---
name: rc-opsec
description: OPSEC layer — proxy rotation, burn list, and jittered timing.
---

# rc-opsec: Operational security

rc-opsec provides OPSEC: proxy rotation, burn lists, and jittered timing.

## 1. Proxy rotation

Rotate through a proxy pool at configurable intervals.

## 2. Burn list

Mark proxies or hosts as burned.

## 3. Jitter

Sleep a jittered interval before every request.

## Usage

Activate when you need operational security for network operations.