---
name: canvas-design
description: Posters, cards, banners and social graphics with the native canvas_design tool — gradient/solid backgrounds, rounded rects, circles, lines, polygons, wrapped text, pills/badges and images from a JSON layout, rendered to PNG with optional PDF export. Use when the user asks for a poster, piece of art, banner or static design.
---

# Canvas Design (canvas_design)

A JSON layout becomes a rendered PNG (and optional PDF) through the pure-
Rust design engine — no HTML canvas, no browser.

## Anatomy

```json
{"preset": "square", "out_png": "poster.png", "out_pdf": "poster.pdf",
 "background": {"type": "gradient", "from": "#0F172A", "to": "#1F77B4", "direction": "vertical"},
 "elements": [
   {"kind": "rect", "x": "6%", "y": "8%", "w": "88%", "h": "84%", "fill": "#FFFFFF", "radius": 24, "opacity": 0.95},
   {"kind": "pill", "x": "10%", "y": "14%", "text": "NEW", "size": 22, "bg": "#1F77B4"},
   {"kind": "text", "x": "10%", "y": "26%", "text": "Big headline", "size": 64, "weight": "bold", "max_width": "80%"},
   {"kind": "text", "x": "10%", "y": "42%", "text": "Supporting line…", "size": 30, "color": "#475569", "max_width": "80%"},
   {"kind": "image", "path": "photo.png", "x": "10%", "y": "55%", "w": 420, "radius": 16},
   {"kind": "line", "x": "10%", "y": "88%", "w": "80%", "color": "#1F77B4", "width": 4},
   {"kind": "circle", "cx": "88%", "cy": "90%", "r": 30, "fill": "#F59E0B"}
 ]}
```

* **Coordinates** accept px numbers or `"50%"` strings (resolved against
  the canvas) — prefer percentages so a design scales across presets.
* **Presets**: square (1080²), story (1080×1920), poster/a3, a4, a2, card
  (1200×630), slide (1920×1080) — or explicit `width`/`height`.
* **Elements**: rect (fill/stroke/radius/opacity), circle, line, polygon
  (`points`), text (size, weight bold, align, `max_width` wraps), image
  (PNG, rounded corners), pill/badge.
* `out_pdf` exports the finished raster as a print-ready single-page PDF.

## Design rules

* Hierarchy: one dominant headline (biggest), one support line, everything
  else quiet. Two type sizes are usually enough.
* Contrast: dark bg → light text; never gray-on-gray. Accents: one hue,
  used for pills, rules and highlights only.
* Margins: keep text inside 8–10% padding; `max_width` prevents overflow.
* Depth: rounded-corner white panels over gradients read well.
* Verify: `png_bytes` in the result must be large (>10 kB) — a tiny file
  means the background drew but elements failed; check element kinds.
