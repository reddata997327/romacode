---
name: remix-contract-dev
description: The full Solidity development loop with the native rrx toolchain — scaffold a workspace, compile with real solc, static-analyze, unit/fuzz/invariant test, measure gas, script-run, flatten, document, deploy (gated), verify, byte-diff, and debug. Stage-by-stage playbook with checkpoints.
---

# remix-contract-dev: the Solidity development loop

The `remix` tool runs the whole Remix IDE contract workflow headlessly. This
skill is the loop, in order, with the checkpoint after each green stage. All
commands go through the `remix` tool (`command` + `args`), never the shell.

## Stage 0 — Doctor

`remix_status` first: binary found, version, RPC policy, chain-write flag.
If the flag is off and the task will end in a deploy, say so now — the user
sets `remix.allow_chain_writes=true` themselves; do not promise a broadcast
you cannot make.

## Stage 1 — Scaffold

- `remix workspace init <template> [name]` with template `storage`, `erc20`,
  or `blank` — creates the project tree. Run it in the intended parent
  directory.
- `remix file tree` / `remix file ls` to see the scaffold; `remix file cat`
  to read files; `remix file write` to edit; `remix search <pattern>
  [--regex]` across the workspace.
- `remix git init`, then `remix git add|commit|status|log` — the built-in
  dgit. **Commit after every green stage** so a bad experiment is
  revertible.

## Stage 2 — Compile (real solc)

- `remix compile [file] [--solc <version>] [--evm-version cancun]
  [--no-opt]`. The solc manager handles versions: `remix solc list`,
  `remix solc install 0.8.24`, `remix solc use <v>` on first use.
- Fix errors top-down; recompile after every fix. `--no-opt` isolates
  optimizer-caused surprises; drop it once clean.

## Stage 3 — Static analysis

- `remix analyze` — the Remix static-analysis checks (tx.origin,
  delegatecall, unbounded loops, unchecked calls…).
- `remix reentrancy` — the dynamic reentrancy mode.
- `remix layout <Old> <New>` — storage-layout upgrade safety between two
  versions of a contract; run it before any upgrade deploy.
- Treat analyzer findings as questions to answer, not noise to silence. Fix
  or document why each is acceptable, then commit.

## Stage 4 — Test

- `remix test` — Solidity unit tests (remix-tests conventions, real chain).
- `remix fuzz <Contract> <fn> [--runs n] [--seed s]` — property testing.
  **Keep the seed** when a failure needs replaying.
- `remix invariant <Contract> [--sequences n] [--depth n]` — foundry-style
  invariant runs; start small (`--sequences 10 --depth 20`), scale up only
  when green.
- `remix coverage` — find what the suite never executes; close the gaps that
  guard invariants, not just lines.
- Slow suites: pass `timeout_secs` on the tool call (up to 1800 s).

## Stage 5 — Gas, docs, script run

- `remix gas estimate` — per-call estimate; `remix gas report` — full
  analytics; `remix gas price` — current fee landscape; `remix gas trace` —
  where the gas goes.
- `remix flatten <file>` — flattened source for verification.
- `remix uml` — mermaid UML from the AST; `remix doc` — natspec → markdown.
- `remix script scripts/demo.rrx` — the deploy/transfer/assert DSL runner
  with a gas report. Note: a script that deploys is a chain write (§7).

## Stage 6 — Byte-level sanity

- `remix bytediff <addr> <Contract>` — compare deployed bytecode against the
  local build. After any deploy or upgrade, bytediff is the receipt that
  what is on chain matches what was compiled. Also use it to clone-audit a
  third-party contract whose address you are integrating with.

## Stage 7 — Deploy and verify (REAL chain, gated)

- Deploys broadcast real transactions: they need
  **`remix.allow_chain_writes=true`** in the config plus `RRX_PRIVATE_KEY`
  in the server environment. If the tool refuses, hand the refusal text to
  the user verbatim and stop — do not work around it with Bash, and never
  pass `--yes` yourself (the tool refuses it).
- Dry-run first: `remix gas estimate`, `remix fork <token>` to test against
  real mainnet state offline, `remix ethcall` for view/pure probing.
- `remix deploy <Contract> [--args "T,T,1000e18"]` — deploy from the
  workspace.
- `remix verify <addr> …` — Sourcify/Etherscan verification (uses
  `ETHERSCAN_API_KEY` when set; `remix flatten` output is the input).
- `remix sources <addr>` — re-fetch the verified source as a cross-check.
- Commit the deployed address + bytediff verdict in the repo notes.

## Stage 8 — Debug

- `remix debug <Contract> <Function> [--max-steps n] [--json]` — step through
  the local run with the real interpreter.
- `remix debugtx 0x<hash> [--max-steps n] [--top n]` — replay a REAL mainnet
  tx (fork spec by actual activation heights) with an opcode gas profile.
- `remix trace 0x<hash>` — call-tree trace from the node (callTracer).

## Worked micro-loop (erc20)

```text
remix_status
remix workspace init erc20 demo
remix compile                       # fix until clean
remix analyze && remix reentrancy   # answer every finding
remix test && remix fuzz Token transfer --runs 500 --seed 42
remix invariant Token --sequences 10 --depth 20
remix coverage                      # close invariant-relevant gaps
remix gas report                    # optimize the hot path
remix git add -A && remix git commit -m "green"
# deploy is gated: user sets remix.allow_chain_writes=true first
remix deploy Token --args "Demo,DEM,1000e18"
remix bytediff 0x<deployed> Token   # receipt: chain == build
remix verify 0x<deployed>
```

## Usage

Activate for contract authoring tasks: "write/deploy/verify a contract",
"why does my test fail", "measure gas", "check upgrade safety", "is the
deployed code the code I compiled". Hand the chain-write refusal text to the
user verbatim when the flag is off. Master reference: `remix-ethereum`.
