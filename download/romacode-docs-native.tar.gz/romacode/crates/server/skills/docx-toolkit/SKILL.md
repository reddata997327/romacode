---
name: docx-toolkit
description: Recipes for Word documents with the native docx_create/docx_read tools — headings, inline formatting, lists, shaded tables, images with captions, quotes, code blocks, a real TOC field and a page-number footer. Use for any .docx deliverable.
---

# Word Toolkit (docx_create / docx_read)

One `docx_create` call writes the whole document; one `docx_read` verifies
it. No Python.

## Block reference

| Block | Fields |
|---|---|
| h1..h4 | `text` — styled headings (blue, keep-with-next) |
| p | `text`, `align` (left/center/right/justify), `size_pt`, `font`, `color` |
| bullets | `items` — strings or `{text, level 0..2}` |
| numbered | `items` — decimal numbering, 3 levels |
| table | `header[]` (blue fill, white bold, repeats on page breaks), `rows[][]`, `widths[]` (relative ratios) |
| image | `path` (png/jpg/gif/bmp), `width_px`, `caption` (Caption style) |
| quote | `text` — indented, italic, blue left border |
| code | `text` — Consolas, shaded, one paragraph per line |
| toc | — real Word TOC field (`TOC \o "1-3" \h \z \u`) |
| pagebreak | — |

Inline markup inside any `text`: `**bold**`, `*italic*`, `__underline__`,
`` `code` ``. Metadata: `title`, `author`, `subject`; `page_numbers: true`
(default) adds a centered PAGE-number footer.

## Recipes

**Report skeleton**: title meta → `h1` overview → `p` ×3 → `toc` →
`pagebreak` → per-chapter `h1` + paragraphs + `table` per dataset →
`image`+`caption` per figure. Keep body paragraphs 3–5 sentences.

**Meeting minutes**: `h2` header per section, `bullets` for decisions with
`level:1` sub-points, `table` for action items (owner / due / status).

**Data appendix**: `xlsx_read` the source workbook first, paste the numbers
into `table` rows — never invent values; ratios via `widths`.

## Verify

`docx_read` on the output: heading styles present, table grid complete, no
placeholder text (`TODO`, `XXX`, `【…】`). Regenerate to fix — never edit by
hand.
