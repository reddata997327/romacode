---
name: claude-parity
description: Feature-parity map between Claude Code (the TypeScript/Ink CLI this project mirrors) and RomaCode v0.7.x - which Claude concepts are ported (tool registry, SKILL.md skills, slash commands, hooks, MCP, permission modes, compaction), which are adapted (client-server split, LangChain engine), and which have no RomaCode equivalent. Use when porting another Claude-Code feature or arguing about "how Claude Code does it".
---

# Claude Code → RomaCode Parity Map

Baseline: the Claude Code source tree measured at 1,899 files / ~512k lines of
TypeScript; RomaCode measured at ~93k lines of Rust. This skill is the honest
crosswalk: what exists on both sides, what is adapted, what is absent.

## 1. Concepts ported one-to-one

| Claude Code | RomaCode | Notes |
|---|---|---|
| Tool registry (`claude/tools/`, 43 entries, 22 in the default pool) | `crates/server/src/tools/mod.rs` (`definitions()` + `execute()`) | Claude gates registration per feature flags; RomaCode registers all 20 always. 14 Claude tools are referenced by the registry but their packages are absent — dead code eliminated at compile time; RomaCode has no such gap. |
| SKILL.md packages (14 built-in skills) | `crates/server/src/skills.rs` + `crates/server/skills/*/SKILL.md` | Same frontmatter (`name`/`description`), same progressive disclosure, 32,000-char body cap on both sides. |
| Slash commands (86 command dirs) | `Hub::run_command` in `api.rs` + client whitelist in `client-tui/src/app.rs` | Claude ships each command as a dir with prompt + tests; RomaCode matches arms in one function. |
| Hooks (104 hook files) | no hook engine | RomaCode has none; pre/post tool-call behavior is hard-coded in `agent.rs`. |
| MCP client (23 files) | `rc-tools` MCP bridge (`rc-sources/src/mcp.rs`) | RomaCode bridges MCP servers into the rc-* framework, not yet into the live 20-tool registry. |
| Permission modes (5: default, acceptEdits, plan, bypassPermissions, delegate) | `security::authorize` with `Permission::Allow/Deny/Ask` per tool group | Owner removed the gating — default posture is autoaccept. Plan mode survives as `Mode::Plan` prompt text. |
| Context compaction (`compact_threshold_pct`) | `auto_compact` + `compact_threshold_pct` config | Same idea: summarize the transcript when the context window fills. |
| Subagents (Task tool) | none | RomaCode has no subagent spawn; long work is a loop of tool calls in one turn. |

## 2. Concepts adapted to the client-server split

Claude Code is one Ink process: the React tree, the agent loop and the tools
share address space. RomaCode splits them:

* **Brain** — `romacode-server` owns the agent loop, provider calls, the tool
  registry, the security gate, config and sessions. The TUI (the `romacode`
  binary) is a screen: HTTP + WebSocket mirror of `SessionSnapshot`, requests
  in `protocol.rs`, events in `events.rs`.
* **Two engines** — the native loop (`agent.rs`) and a LangChain
  `AgentExecutor` clone (`langchain_bridge.rs`) share the same registry and
  gate; Claude Code has a single engine.
* **50,000-char tool-result cap** (Claude) becomes
  `max_tool_output_bytes` (default 100,000) with a hard truncation notice in
  `agent.rs`.

## 3. Claude-Code features with no RomaCode equivalent

1. Plugins and marketplaces.
2. OAuth account login (RomaCode: API keys per provider in config.json only).
3. Background bash shells and shell-snapshot forwarding.
4. IDE integrations (VS Code / JetBrains extensions).
5. `@`-file mentions and drag-and-drop image paste (screenshots arrive via
   `android_screenshot` paths instead).
6. Telemetry/analytics service (RomaCode has a `telemetry: false` flag and
   nothing else).

## 4. Using this map

When porting a Claude-Code behavior: find the row above, keep the RomaCode
seam rules (one registry, one gate, wire contract additive, config stays in
the brain), and prefer the smallest surface: prompt text > config key > tool >
protocol change. Verify with `cargo build --workspace --locked` and the
`api.rs` approval end-to-end test.
