---
name: remix-ethereum
description: RomaCode's native Remix/Ethereum toolchain (rrx) — run Solidity compile/test/fuzz/deploy/verify and live mainnet inspection (ethcall, trace, debugtx, MPT proofs, ENS, tokens) through the remix tool. Master playbook: tool schemas, the full 52-command catalog by plane, safety gates, timeout/output policy, and failure recovery.
---

# remix-ethereum: the native Remix toolchain (master playbook)

RomaCode ships **rrx** — Remix IDE tools rebuilt in pure Rust — as a built-in
native tool, wired the same way as rnmap/browser/android. One binary, no
simulation: a real EVM interpreter (Istanbul → Cancun by real activation
heights), real MPT state, real gas metering, real solc, real secp256k1
signing, and every chain-facing command hard-wired to **Ethereum mainnet**
with live endpoint probing and automatic failover.

Architecture in one line: `rrx-evm::Host` is the seam — the same interpreter
runs against local state (`WorldState`) and against live network state
(`RemoteHost`), which is how `debugtx` replays real mainnet transactions.

## 1. The two agent tools

**`remix`** — run one rrx command:

```json
{"command": "ethcall",
 "args": ["0xdAC17F958D2ee523a2206206994597C13D831ec7", "totalSupply()", "--returns", "uint256"]}
```

| param | type | meaning |
|---|---|---|
| `command` | string | one rrx command word (§2), or `help` for the full syntax reference |
| `args` | string[] | one argument per element: `["latest"]`, `["0x<txhash>"]`, `["--rpc", "https://…"]` |
| `timeout_secs` | integer | per-call timeout override, 1..1800 |

**`remix_status`** — the doctor, no arguments. Reports: which rrx binary was
found and where, its version, the active RPC policy, the command allowlist,
the chain-write flag, timeout and output cap.

Session discipline:

1. Call `remix_status` **before the first remix command of a session**.
2. If any remix call fails oddly, call `remix_status` again before
   improvising — the doctor names the failing layer (binary, RPC, policy).
3. `command="help"` returns the complete per-command syntax reference; prefer
   it over guessing flags.

If the binary is missing, build it from the workspace (rrx is a first-party
member at `crates/remix/rrx-cli` — the doctor prints exactly the paths it
searched):

```bash
cargo build --release                # at the romacode workspace root
cp target/release/rrx bin/rrx        # next to the romacode binary, or:
# set "remix": {"binary": "/abs/path/to/rrx"} in the config
```

## 2. Command catalog (the 52 allowed commands)

**Project plane** — run inside a workspace (`workspace init` first):

- `workspace init <storage|erc20|blank> [name]` — scaffold from Template
  Explorer; `file ls|tree|cat|write|rm|mv|mkdir` — file explorer;
  `search <pattern> [--regex]` — workspace search
- `compile [file] [--solc <version>] [--evm-version cancun] [--no-opt]` —
  real solc; `test` — solidityUnitTesting conventions
- `analyze` — static analysis (tx.origin, delegatecall, unbounded loops…);
  `reentrancy` — dynamic reentrancy mode
- `coverage` — what the suite never executes
- `fuzz <Contract> <fn> [--runs n] [--seed s]`,
  `invariant <Contract> [--sequences n] [--depth n]`
- `gas estimate|report|price|trace` — hardhat-style analytics
- `flatten <file>`, `uml` (mermaid from the AST), `doc` (natspec → markdown)
- `debug <Contract> <Function> [--max-steps n] [--json]` — local debugger;
  `layout <Old> <New>` — storage-layout upgrade safety;
  `bytediff <addr> <Contract>` — deployed vs local bytecode
- `verify <addr> …` — Etherscan V2 / Sourcify; `script <file.rrx>` — the
  deploy/transfer/assert DSL runner; `git init|add|commit|status|log`

**Account plane** (offline, secp256k1/EIP-191): `keys new|list|dev`,
`sign`, `precompiles` (0x01–0x09), `aa` (account abstraction).

**Chain-read plane** — LIVE mainnet, no key needed:

- `net` — probe ALL endpoints (latency, head, client); run when numbers look
  stale. `chain` — client/head/base fee/priority fees. `chains [slug] [--json]`
- `block <n|latest|finalized>`, `tx 0x<hash>` (tx + receipt report),
  `trace 0x<hash>` (callTracer call tree)
- `debugtx 0x<hash> [--max-steps n] [--top n]` — replay a REAL mainnet tx in
  the built-in EVM and compare chain gas vs replay gas with an opcode profile
- `account <ADDRESS|ens.name>` (balance/nonce/code; resolve via `ens` first),
  `ethcall <to> <fn signature> [args…] [--types "address,uint256"]
  [--returns "uint256"] [--block n]` — arbitrary view call at any block
- `logs --address <a> [--topic0 "Event(types)"] [--from …] [--to …]`
- `ens <name>` / `ens --reverse <addr>`, `token <addr> [--holder <h>]`
  (ERC-20/721/1155), `sources <addr> [--chain 1]` (Sourcify → Etherscan V2)
- `proof <addr> [--slot n] [--block tag]` — MPT account/storage proofs
  verified locally against the block stateRoot (own RLP + Merkle walk; a
  lying node cannot pass)
- `gasprice`, `fork <usdt|usdc|weth|dai|0x…> [--chain] [--block]` — preload
  real mainnet state offline, `blob`, `verkle`, `build-block`, `index`

**Chain-write plane** — REAL broadcasts, gated (§3): `send --to <who>
--value <eth> [--fn "sig"] [--args "…"]`, `deploy <Contract>
[--args "…"]`, `call`.

**Meta**: `wildtoken` (teaching demo token), `fakeasset` (detection stack:
`registry [--verify-live]`, `registry --compare 0x… --chain ethereum`,
`variants`, `audit`, `pending`), `utils keccak|unit|selector|namehash`,
`solc install|list|use`, `plugins` (the full 38-tool registry).

**Never available as tools** (daemon commands, they never return): `node`,
`explorer`, `follow`, `mcp`, `lsp`, `ws`. If a task truly needs one, start it
with the Bash tool and manage the process yourself.

## 3. Safety model (do not work around any of these)

- Chain-writing commands (`send`, `deploy`, `call`, `script` runs, demo
  deploys incl. `wildtoken|fakeasset deploy`) broadcast REAL transactions to
  chain id 1. They are refused unless **`remix.allow_chain_writes=true`** in
  the config **and** `RRX_PRIVATE_KEY` is exported in the server environment.
  While the flag is off, the key env var is stripped from the child process.
- Never pass `--yes` yourself — the tool refuses it; a broadcast is a human
  decision made in the config. rrx itself layers no-key → no-`--yes` →
  balance-check before any broadcast.
- Never echo a private key, seed phrase, or keystore password into args,
  output, or reports.
- Prefer the read-only equivalent: `ethcall` over `call`, `gas estimate`
  over deploy-to-measure, `fork` for mainnet-state experiments, `debugtx`
  over re-broadcasting.

## 4. Output, timeouts, failure recovery

- Add `--json` where supported when the next step must parse the result.
- Output is capped by `remix.max_output_chars` (default 20 000, clamped
  1 000..200 000). If output truncates, narrow the query (filter logs by
  topic, read one slot, one function) instead of paging.
- Whole-command timeout `remix.timeout_secs` (default 300 s, clamp 0..3600).
  The slow commands are `compile` on big trees, `test`, `fuzz --runs 1000`,
  `invariant --sequences 50`, `coverage`; pass `timeout_secs` per call up to
  1800 s.
- Missing binary → doctor names the search order (`remix.binary` config →
  exe-adjacent `bin/rrx` → `<data_dir>/romacode/bin/rrx` → PATH → project
  `bin/`); build per §1.
- Endpoint trouble → `remix net` probes every endpoint with latency and head
  info; set `remix.rpc` in the config (global `RRX_RPC`) or `--rpc <url>`
  per call.
- The `/remix` slash command (TUI): `on|off`, `status` (the doctor),
  `writes on|off`, `help`.

## Usage

Activate when the task touches Ethereum: Solidity contracts, EVM behavior,
gas, mainnet state, transactions, ENS, tokens, MPT proofs, fake-asset
auditing, or "remix" workflows. Do not shell out to `forge`/`cast`/web
explorers for what rrx already does natively. For the full dev loop see
`remix-contract-dev`; for investigations see `remix-chain-forensics`.
