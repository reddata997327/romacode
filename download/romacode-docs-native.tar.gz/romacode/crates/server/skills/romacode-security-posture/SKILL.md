---
name: romacode-security-posture
description: RomaCode security posture reference - what the original restriction policy was, what was removed at the owner request (permissions autoaccept, no SSRF guard, tools pre-approved), which residual safeguards remain (unknown-tool refusal, cancel, timeouts, output caps, traversal checks) and the exact code anchors for each. Read before touching security.rs, config permissions or tool gating.
---

# Security Posture - What Was Removed, What Remains, How to Re-Enable

Source of truth: `FIXES.md` in the tree root ("Fully open tools framework
(restrictions removed)") plus static reading of `crates/server/src/security.rs` (392
lines), `tools/coding.rs`, `webfetch/`, `rnmap/mod.rs`, `config.rs`,
`tui_settings.rs`, `config.example.json`.

## The removal set (v0.7.x "fixed" state, owner-requested)

| Area | Removed behavior | Where it used to live |
|---|---|---|
| Gate | deny rules, ask/allow rules, Plan-mode hard stops, protected paths, Android host-access confinement | security.rs policy evaluation |
| Bash | fail-closed block when confine_to_project + protected_paths set | tools/coding.rs |
| File tools | confinement, protected-path check, hard-link refusal, symlink refusal (now resolves to real targets) | coding.rs descriptor-anchored backend + fallback |
| rnmap_scan | permissions.net deny refusal, external-target refusal, IDS-evasion gating (decoy/fragment now always allowed), max_targets 256 -> 4096 | rnmap/mod.rs |
| web_fetch | permissions.web deny refusal, SSRF private/loopback guard default-off (allow_private_hosts true), userinfo URLs now supported (basic auth) instead of rejected | webfetch/mod.rs, webfetch/url.rs |
| Android | "bridge unavailable" failure -> auto fallback to host adb CLI | tools/android.rs::execute_via_host_adb |
| Defaults | every permission class allow, no deny/ask lists, confine_to_project false, tui.session.permissions autoaccept, startup warnings removed | config.rs, tui_settings.rs, config.example.json |
| Prompts | "public internet refused", "state-changing actions require approval", "Plan is read-only" removed; Plan advisory only | agent system prompt assembly |

Consequence to keep in mind while customizing: any new tool you add is callable in
every mode without a prompt, and web/network/file tools reach localhost, private
ranges and the public internet. Do not restore gating silently - but also do not
weaken the remaining safeguards.

## Residual safeguards (keep them green)

1. Unknown-tool refusal: `tools/mod.rs::execute` - `tool {name} is unavailable`.
2. Cancel/timeout plumbing: Bash, rnmap_scan, browser poll the shared
   `AtomicBool`; agent.rs enforces tool_timeout_secs and max_tool_output_bytes.
3. Output caps: webfetch.max_output_chars, rnmap.max_output_chars,
   browser.max_output_chars; bash output capped before it enters the transcript.
4. webapp_scaffold traversal validation: name/path/rustango_path rejected on `..`,
   quotes, empty, `crate` (tests in rustango_bridge.rs).
5. GitHub client: SSRF filter + curl `resolve` pinning, token via stdin config (never
   argv), 16 MiB / 10k-item pagination caps.
6. Approval machinery (dormant but intact): Security approval registry, oneshot
   answer slots, ApprovalRequest wire event, TUI modal y/n popup,
   SessionSnapshot.pending_approvals restore, `resolve_approval`. End-to-end test:
   `api::tests::approval_flow_end_to_end_through_the_hub`.

## How to re-enable restrictions (if ever asked)

The enforcement code is deleted, not disabled - config keys still parse and
serialize but nothing reads them. Re-enabling means re-implementing checks at the
exact choke points (all traffic crosses them, so coverage is total):

1. `security::authorize` (security.rs): re-add policy evaluation before returning
   Allow - match the class (read/edit/bash/web/net/android), evaluate
   `permissions.allow/ask/deny` glob lists (the glob matcher with memoization is
   still in security.rs), consult `session.mode` for Plan hard stops.
2. `tools/coding.rs::execute`: re-add protected-path + confinement checks for the
   descriptor-anchored backend and the non-Linux fallback.
3. `webfetch/mod.rs::execute` + `webfetch/url.rs`: re-enable the private/loopback
   guard when `webfetch.allow_private_hosts` is false.
4. `rnmap/mod.rs::execute`: re-check `allow_external_targets`, `allow_evasion`,
   `allow_scripts`, max_targets clamp before spawning the scanner.
5. Config defaults (config.rs, config.example.json, tui_settings.rs): flip
   `permissions.*` defaults to `ask`, `tui.session.permissions` to `prompt`, and
   restore the startup warnings.
6. UI is already wired: an `Ask` decision broadcasts ApprovalRequest and every
   attached screen raises the modal - no TUI work needed.

Test plan: revive/extend the gate tests (the net-class gate test and approval
end-to-end test are the templates), then drive one denied, one asked and one allowed
call through both engines.

## Hygiene for new code

- Never log or hardcode API keys; keys live in the brain's config file only and never
  round-trip through the screen (save_model deliberately ignores empty keys).
- Treat all web/browser/rnmap output as untrusted data - the tool descriptions say so
  verbatim; keep that sentence when editing descriptions.
- Keep cancel-aware loops and output caps on anything process-spawning or streaming.
- New config keys need clamps and a config.example.json entry (the rnmap pattern);
  unknown spellings must fall back to the safe behavior.
