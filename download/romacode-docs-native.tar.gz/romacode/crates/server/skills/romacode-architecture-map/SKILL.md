---
name: romacode-architecture-map
description: Complete RomaCode architecture map - every crate, module, config key and wire type in the romacode-fixed-v3 workspace, with line counts and the ownership boundaries between the brain (romacode-server) and the screen (romacode TUI). Use when planning any structural change, locating the code that owns a behavior, or explaining how RomaCode works internally.
---

# RomaCode Architecture Map (romacode-fixed-v3, CHANGES v0.7.6)

Measured statically: 316 files, ~99,800 text lines across the workspace. Cargo
workspace: 17 members, resolver 2, edition 2021, rust-version 1.75, MIT. Release
profile: opt-level 3, thin LTO, codegen-units 1, strip. Binaries: `romacode-server`
(brain) and `romacode` (screen). Brain binds 127.0.0.1:7712; the screen auto-spawns it
detached (setsid) and reconnects losslessly from snapshots.

## Crate inventory

| Component | Role | Files | Lines |
|---|---|---|---|
| crates/shared | Wire contract: protocol, events, catalog, tui_settings | 9 | 3,073 |
| crates/server (brain) | Agent loop, sessions, gate, tools, api/bus, config | 29 | 16,266 |
| crates/server/langchain | LangChain rebuilt in Rust (vendored engine) | 27 | 5,241 |
| crates/server/rustango (+macros) | Django-style web framework | 46 | 15,805 |
| crates/server/mandroid | ADB wire protocol + APK analysis/signing | 30 | 18,841 |
| crates/server/rnmap | Vendored rnmap 0.4.0 (binary + 24 Rhai scripts) | 26 | 852 |
| crates/server/roxterm | Terminal core (protocol, graphics, VT) | 8 | 4,767 |
| crates/server/phone | Legacy handset simulator (tests only) | 17 | 12,321 |
| crates/client-tui (screen) | WS client, UI mirror, pixel renderer, desktop window | 32 | 11,442 |
| crates/rc-tools/rc-core | Tool trait, schema, registry, executor, sandbox | 11 | 1,679 |
| crates/rc-tools/rc-builtin | 38 shipped tools in 8 categories | 10 | 1,452 |
| crates/rc-tools/rc-sources | 8 tool-source mechanisms | 12 | 1,747 |
| crates/rc-tools/rc-compose | pipeline, parallel, branch, dag, iter + templating | 8 | 1,281 |
| crates/rc-tools/rc-lifecycle | discover/register/validate/load/execute + monitor | 4 | 350 |
| crates/rc-tools/rc-rust | 8 rust.* tools; re-exports the rc-* surface | 4 | 515 |
| crates/rc-tools/rc-python | Standalone Python mirror (PEP 517) | 36 | 3,214 |
| docs | WEBFETCH.md, RNMAP.md, SETTINGS.md, BROWSER.md | 4 | 540 |
| scripts | install.sh, e2e_ws.py, browser_live_site.py | 3 | 436 |

## Brain file map (crates/server/src/)

| File | Lines | Contents |
|---|---|---|
| config.rs | 1,719 | Config model, defaults, clamps, provider resolution, save |
| api.rs | 1,702 | HTTP/WS endpoints, Hub, run_command, approval resolve, tests |
| webfetch/html.rs | 1,294 | HTML -> text/markdown readability pipeline |
| agent.rs | 1,261 | Think-act-observe loop, both engines, retries, id synthesis |
| android/mod.rs | 1,171 | Bridge thread, frame streaming |
| rnmap/mod.rs | 1,043 | Scanner engine: embed, install, run, parse |
| browser/mod.rs | 771 | Servo WebDriver session + 15 actions |
| tools/coding.rs | 679 | Read/Edit/Bash definitions + executors |
| rustango_bridge.rs | 668 | webapp_scaffold / webapp_check |
| langchain_bridge.rs | 590 | langchain engine adapter + rag tools |
| security.rs | 392 | THE gate (fully open; see security-posture.md) |
| providers.rs / providers_cli.rs | - | Provider resolution + CLI listings |
| github.rs / github_engineering.rs | 585+ | REST research client (SSRF-pinned curl) |
| session.rs, main.rs, tools/mod.rs | - | Sessions, CLI entry, tool registry |

## The 20 registered brain tools

Read, Edit, Bash (tools/coding.rs) - android_device, android_shell, android_tap,
android_swipe, android_text, android_key, android_screen, android_screenshot,
android_install, android_launch, android_packages (tools/android.rs; 11 tools, host
adb fallback via execute_via_host_adb) - web_fetch (webfetch/, 8 modes) - rnmap_scan
(rnmap/, 8 scan types, 5 profiles, 24 scripts) - browser (browser/, 15 actions) -
rag_index, rag_search (langchain_bridge) - webapp_scaffold, webapp_check
(rustango_bridge). Conditional: webfetch.enabled / rnmap.enabled / browser.enabled;
the other 17 always registered. OpenAI providers get the same set wrapped as
`function` definitions by tools/mod.rs.

## Wire contract

- Requests (shared/src/protocol.rs): Hello, NewSession, CloseSession, SelectSession,
  Message, Approval, Cancel, ToggleMode, Command, FetchModels, SaveModel, SetUiPref,
  Android, Ping.
- Events (shared/src/events.rs): Text, ToolStart, ToolEnd, Usage, ApprovalRequest,
  Notice, Error, Done, Snapshot, Sessions, Frame, Device.
- REST (read-only): GET /api/health, /api/sessions, /api/config, /api/rag. Interactive
  channel: WS /ws.
- Server CLI: serve (default), fetch, providers, models, provider, model, github,
  --verify-android, --print-config, --config-path.
- Slash commands (server, Hub::run_command): providers, provider, models, model,
  baseurl, apikey, customprovider, engine, mode, rounds, webfetch, rnmap, timeout,
  context, prefs|settings. Client-local (app.rs): new, clear, panel, quit/exit.
  Client whitelist gap: /rnmap and /settings not in the client's provider_cmd list.
- Keyboard: Enter send, Alt+Enter newline, Tab mode, Esc interrupt, Ctrl+N/W sessions,
  Ctrl+B panel, Alt+A android, Alt+T native terminal, Ctrl+P palette, Ctrl+Q quit.

## Config manifest (~/.config/romacode/config.json; 213 flattened keys)

Top-level: version, provider, model, api_key_env, api_base, max_tokens 4096,
system_prompt, context_window 200000, price_in/out_per_mtok, chat_width_pct, sidebar.
Sections: model_params (9), agent (9: engine, default_mode, max_tool_rounds 200,
parallel_tools, tool_timeout_secs 120, max_tool_output_bytes 65536, auto_compact,
compact_threshold_pct 85, instruction_files [ROMACODE.md, AGENTS.md, CLAUDE.md],
system_prompt_append), permissions (11: all classes allow, lists empty,
confine_to_project false), ui (15), keys (11), network (8), sessions (5), privacy (3),
android (4: backend adb, adb_path, serial, auto_start), advanced (4), providers map,
webfetch (10: enabled, default_mode text, max_body_bytes 4MiB, max_output_chars 20000,
timeout 30s, max_redirects 5, allow_private_hosts true, domains, render, browser),
rnmap (10: enabled, binary, default_ports 1-1000, default_timing 3, timeout 300s,
max_targets 4096, max_output_chars, allow_external_targets true, allow_evasion true,
allow_scripts true), browser (10: enabled, binary, host, port, headless true,
accept_insecure_certs true, auto_start, timeouts, extra_args, max_output_chars 200000),
tui (~40: theme, keybinds, plugins, leader, scroll, attention, diffs, terminal, prompt,
session.permissions autoaccept, tabs, mini, debug, experimental).

## Provider catalog (shared/src/catalog.rs, 31 rows)

anthropic (Anthropic wire); openai-compatible: openai, openrouter, google, groq,
deepseek, mistral, xai, together, fireworks, cerebras, perplexity, cohere, ai21,
replicate, deepinfra, lepton, hyperbolic, sambanova, novita, chutes, nebius,
huggingface, friendli, alephalpha, ollama, lmstudio, azure, nvidia, coarena, logfare.
Each row: id, name, kind, base_url, key_env, needs_key, default_model, models.
Custom providers via the config `providers` map. Embeddings for RAG go to the resolved
provider (ROMACODE_EMBEDDINGS_MODEL override).

## Subsystems

- langchain: runnables (LCEL), prompts, messages, output_parsers, text_splitter,
  vectorstores, embeddings/openai, llms/openai, memory, agents (+tools,
  tools_builtin), callbacks, errors, cli/langchain-cli REPL, 4 examples.
- rustango: http, urls, views, orm (backend/model/query/migrations), templates
  (parse/filters), forms, admin (+6 templates), auth, sessions, csrf, i18n, cache,
  middleware, signals, staticfiles, testclient, management, project, settings,
  contrib/ai, bin/rustango CLI, macros crate.
- mandroid: adb, api, apk, arsc, axml/axmlenc, crypto, dex, smali, manifest, sign,
  key, repack, modify, scan, pipeline, net, device, identity, screen, sim, util,
  tools.rs (legacy android_* catalog beyond the 11 registered), android-rules.json,
  test APKs.
- rnmap: prebuilt binary + provenance README + 24 Rhai scripts (banner_grab,
  dns_version, http_headers, http_methods, http_robots, http_security_headers,
  http_server_status, http_title, mdns_query, mongodb_probe, mysql_probe,
  netbios_name, ntp_version, postgres_probe, rdp_probe, redis_info, rpc_dump,
  smb_enumerate, smb_negotiate, snmp_info, ssh_algorithms, ssh_version,
  tls_cert_info, vnc_banner).
- browser bridge: Servo via WebDriver; frontend (screenshots, DOM) + backend (eval,
  Performance-API network log, cookies); headless default; no URL restrictions.
- roxterm: rox-protocol, rox-graphics, rox-vt + INTEGRATION.md (provenance).
- phone: legacy simulator (adbd, apps incl. Termux sim, shell, gfx, os, persist,
  theme, net_fetch, 4 examples) - tests only, never the default backend.
- client-tui: app.rs 3,054 lines (state machine), net.rs pure-std WS client, session,
  device, display (scrcpy-style minifb window), settings, terminal, tree, input,
  autostart + 21 ui/ modules.

## Build, install, test

- `cargo build --workspace --locked`; `cargo test --workspace --locked`.
- `bash scripts/install.sh` (Kali; apt deps + rustup + release build + PATH; uses
  prebuilt bin/ if present, `--build` to force compile, `--no-adb` to skip adb).
- Manual: X11/XKB/Wayland dev packages (minifb desktop window), adb, rustup stable.
- Runtime data: ~/.local/share/romacode/ (server.log, server.pid, rnmap install);
  config: ~/.config/romacode/config.json.
- v0.7.6 fix state (CHANGES.md): synthesized tool-call ids (both engines), provider
  retry 4 attempts 2/4/8/16s cancel-aware, max_tool_rounds 25 -> 200 with wrap-up
  round, model saving fixes (anthropic-version header, key preserved on empty
  save_model), approval popup chain fixed end to end.
