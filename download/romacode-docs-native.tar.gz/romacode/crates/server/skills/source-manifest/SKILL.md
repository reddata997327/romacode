---
name: source-manifest
description: Measured manifest of the romacode-fixed-v3 workspace - every crate with its purpose, file count and line count, the embedded subcomponents (LangChain clone, rustango, rnmap, mandroid, Servo browser, phone simulator, roxterm), test locations and the numbers to quote when reporting sizes. Use when writing docs, changelogs or comparing trees.
---

# RomaCode Source Manifest (measured)

Workspace root `Cargo.toml` (version 0.1.0) with members under `crates/`:
`client-tui`, `rc-tools/*`, `server`, `shared`, plus the server-internal
component crates. All counts below were measured on the romacode-fixed-v3
tree (~93k lines of Rust, 323 files).

## Crates

| Path | Purpose |
|---|---|
| `crates/server` | The brain: agent loop (`agent.rs`), 20-tool registry (`src/tools/`), security gate (`security.rs`), config (`config.rs`), HTTP+WS hub (`api.rs`), providers (`providers.rs`, `providers_cli.rs`), sessions, skills (`skills.rs`), bridges. |
| `crates/client-tui` | The screen: ratatui UI, panels, phone view, net client mirroring `SessionSnapshot`. |
| `crates/shared` | Wire protocol (`protocol.rs`, `events.rs`), provider catalog (`catalog.rs`, 31 known rows), TUI settings catalog. |
| `crates/rc-tools` | Standalone tool framework (registry, lifecycle, CLI): `rc-core`, `rc-builtin` (38 builtins), `rc-sources` (declarative/cli/rest/openapi/mcp/marketplace). Not merged into the live brain registry. |

## Server-embedded components

| Path | Purpose |
|---|---|
| `server/langchain` | LangChain clone: AgentExecutor, prompts, memory, vector store for `rag_index`/`rag_search`. |
| `server/rustango` | Django-style web framework used by `webapp_scaffold`/`webapp_check` via `rustango_bridge.rs`. |
| `server/rnmap` | Network scanner behind `rnmap_scan` (15 engine tests). |
| `server/mandroid` | APK toolchain: axml/arsc/dex/smali parse, manifest edit, sign/verify v2, repack, adb wire client (`adb.rs`), identity anti-emulator scrub, scan. Ships `data/android-rules.json` and test APKs. |
| `server/phone` | Legacy in-process phone simulator (adbd, shell, state, theme). Not selected as a fallback by the app; kept for tests. |
| `server/roxterm` | Terminal emulation (rox-vt) for the desktop experience. |
| `server/src/android/` | The live Android path: `mod.rs` bridge + `adb_cli.rs` official Platform-Tools adapter, `setup.rs` environment bootstrap. |
| `server/src/browser/` | Servo-engine browser tool (navigate/eval/dom/screenshot/network/cookies). |
| `server/src/webfetch/` | `web_fetch` tool. |

## Tests

* `crates/server/tests/browser_live.rs` — end-to-end browser.
* `api.rs` tests — approval flow end-to-end, command dispatch.
* `android/adb_cli.rs` — discovery against a fake adb script.
* `skills.rs` — parsing, override, catalog, builtin library integrity.
* `mandroid` fixtures — `testdata/test-app.apk` (signed) and
  `testdata/test-app-unsigned.apk`.
* `rnmap` — 15 engine tests.

## Numbers to quote

* Brain tools registered: 20 (always; both engines).
* Provider catalog rows: 31.
* Builtin skills: 9 (romacode-customization, romacode-architecture-map,
  romacode-security-posture, romacode-tool-recipes, claude-parity,
  source-manifest, docx-report, unlock, android-setup).
* Config: single `~/.config/romacode/config.json`, sections `agent`,
  `model_params`, `providers`, `android`, `rnmap`, `browser`, `tui`.
* Binaries after `cargo build --workspace`: `target/release/romacode-server`,
  `target/release/romacode`.
