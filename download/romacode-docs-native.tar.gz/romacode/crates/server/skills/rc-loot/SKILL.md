---
name: rc-loot
description: Append-only loot ledger for engagement databases.
---

# rc-loot: Append-only loot ledger

rc-loot records hosts, services, vulnerabilities, credentials, sessions, cards, transactions, wallets, and artifacts with SHA-256 evidence hashes.

## 1. Tables

Host, Service, Vuln, Cred, Session, Card, Txn, Wallet, Artifact.

## 2. Evidence requirement

Vuln, Cred, and Card rows require an evidence_sha256 before insertion.

## 3. Operations

- insert(row) — add a row with evidence verification
- set_status(table, id, status) — update row status
- counts() — count rows per table
- query(selector, limit) — typed selector
- hash_file(path) — SHA-256 hash a file
- export(dest) — export all tables with hash verification

## Usage

Activate when recording engagement data into the loot ledger.