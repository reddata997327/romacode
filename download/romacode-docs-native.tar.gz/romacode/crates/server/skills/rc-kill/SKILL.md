---
name: rc-kill
description: Attack chain orchestrator.
---

# rc-kill: Chain orchestrator

rc-kill orchestrates multi-step attack chains.

## 1. Chain definition

Define chains of offensive operations with dependencies and ordering.

## 2. Orchestration

Execute chains step by step, handling failures and rollbacks.

## Usage

Activate when chaining multiple offensive operations into coordinated kill chains.