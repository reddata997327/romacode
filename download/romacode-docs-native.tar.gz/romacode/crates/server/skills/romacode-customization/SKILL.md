---
name: romacode-customization
description: Exact customization recipes for RomaCode, the Rust client-server coding agent (romacode-fixed-v3 source tree, CHANGES v0.7.6 state). Use this skill whenever the user wants to modify, extend, reconfigure, rebuild or integrate RomaCode - adding an agent tool (brain tool, rc-* declarative/CLI/REST/OpenAPI/MCP tool), changing the security gate or permission defaults, adding a slash command or a provider, tuning the agent loop or config, wiring the rc-tools framework into the brain, or re-shipping the binaries. Triggers on any mention of RomaCode, romacode-server, the romacode TUI, its tools (web_fetch, rnmap_scan, browser, rag_index, rag_search, webapp_scaffold, webapp_check, android_*, Read/Edit/Bash), its config.json, its rc-tools workspace, or porting Claude-Code-style features into it.
---

# RomaCode Customization

RomaCode is a Rust client-server coding agent: `romacode-server` (the brain) owns the
agent loop, sessions, the 20-tool registry and the security gate; `romacode` (the TUI
screen) only mirrors state over HTTP + WebSocket. Every customization lands in one of
six seams. Work server-side first: the brain owns the config file, the tool registry
and the policy, and the screen adapts.

Assume the tree root is the extracted workspace (here:
`/home/z/my-project/analysis/romacode/romacode/`). All paths below are relative to it.

## Golden rules

1. **One registry, one gate.** Agent tools live in `crates/server/src/tools/mod.rs`
   (`definitions()` + `execute()`). Any tool call - both engines - passes
   `security::authorize` first. Never add a second dispatch point.
2. **Both engines must keep working.** The native loop and the langchain
   `AgentExecutor` share the registry and gate. A new tool needs only a `definitions()`
   entry plus an `execute()` arm; both engines pick it up automatically.
3. **The posture is fully open by design.** FIXES.md records that all restriction
   policy was removed at the owner's request. Do not silently re-add gating; do not
   silently remove the residual safeguards (unknown-tool refusal, cancel/timeout,
   output caps, scaffold traversal checks). See
   `references/security-posture.md` before touching policy.
4. **The wire contract is the freeze boundary.** Requests live in
   `crates/shared/src/protocol.rs`, events in `events.rs`. Extending either is
   additive only, or old screens desync (they resync from `SessionSnapshot`).
5. **Keys and config never touch the screen.** Providers, keys and settings persist in
   the brain's `~/.config/romacode/config.json`; the screen sends empty keys on
   purpose. Keep it that way.
6. **Build locked, test everything.** `cargo build --workspace --locked` then
   `cargo test --workspace --locked`. Binaries: `target/release/romacode-server` and
   `target/release/romacode`. `scripts/install.sh` is the packaging path.

## Pick the seam

| Goal | Anchor files | Recipe |
|---|---|---|
| Add an agent tool the model can call | `crates/server/src/tools/mod.rs`, new module under `crates/server/src/tools/` | Recipe A (below) + `references/tool-recipes.md` |
| Add a tool without Rust changes | `crates/rc-tools/rc-sources/` | Recipe B |
| Wire the rc-* framework's tools into the brain | `tools/mod.rs` + `rc-builtin`/`rc-sources` | Recipe B2 |
| Change policy / permissions / defaults | `crates/server/src/security.rs`, `config.rs`, `config.example.json` | `references/security-posture.md` |
| Add a slash command | `crates/server/src/api.rs` (`Hub::run_command`) + `crates/client-tui/src/app.rs` (`send`) | Recipe C |
| Add a provider | `crates/shared/src/catalog.rs` (`KNOWN`) or `providers` config map | Recipe D |
| Tune the loop / context / prompts | `agent`, `model_params`, `system_prompt` config keys | Recipe E |
| Extend the wire protocol | `crates/shared/src/protocol.rs`, `events.rs`, `api.rs` | Rule 4; mirror in `client-tui/src/net.rs` |

## Recipe A - add an agent tool (brain)

1. Create `crates/server/src/tools/<name>.rs` with two functions, copying the shape of
   `webfetch.rs` (simplest example):
   - `definition() -> serde_json::Value` in Anthropic shape: `name` (lowercase
     snake_case; `Read`/`Edit`/`Bash` are the only CamelCase exceptions), one-sentence
     `description` (the model reads it), `input_schema` (object, properties, required).
   - `execute(cfg, input, cancel) -> Result<String, String>`: pure, cancel-aware
     (poll `cancel` in loops like `rnmap/mod.rs` does), returns user-facing `Err`
     strings, caps output size (see `max_tool_output_bytes` consumer in `agent.rs`).
2. Register in `tools/mod.rs`: `pub mod <name>;` then inside `definitions()` add your
   definition to **both** the Anthropic branch and the OpenAI branch (the OpenAI branch
   wraps via the `wrap` closure automatically - just push into `defs` in both arms).
   Make it conditional on a config flag if it launches processes (pattern:
   `if cfg.<section>.enabled { defs.push(<name>::definition()); }`).
3. Dispatch in `tools/mod.rs::execute()`: add the match arm. Keep it dispatch-only -
   permission checks belong to `security.rs`, work to the module.
4. Add unit tests next to the executor plus an end-to-end test in
   `crates/server/src/api.rs` tests if the tool changes snapshots/events.
5. Document the tool in README.md's tool list and (if it needs config) extend
   `config.rs` + `config.example.json` with a clamped section (pattern: `rnmap`).

## Recipe B - add a tool with no Rust code (rc-sources)

The `rc-tools` stack is a self-contained framework (its own registry, lifecycle, CLI)
that is a workspace member but is **not yet merged into the brain's live registry** -
the brain's 20 tools are entirely `tools/mod.rs`. For tool authoring it offers:

- **declarative**: a YAML/JSON spec becomes a shell tool (`rc-sources/src/declarative.rs`)
- **cli**: binary + arg-template (`cli.rs`, uses `shell_quote` escaping)
- **rest / openapi**: one endpoint -> one tool; an OpenAPI 3 spec -> N tools
- **mcp**: an MCP `tools/list` manifest bridged to tools (`mcp.rs`)
- **marketplace / llm_gen**: manifests and natural-language specs

Author the spec, then verify through the framework's own CLI/lifecycle
(`rc-lifecycle`: discover -> register -> validate -> load -> execute).

## Recipe B2 - wire rc-* tools into the brain

If the user wants rc-* tools (38 builtins, composed tools, imported MCP/REST tools)
agent-callable:

1. Add `rc-builtin` (and `rc-sources` if importing) to
   `crates/server/Cargo.toml` (workspace path deps already exist in the root
   `[workspace.dependencies]`).
2. In `tools/mod.rs::definitions()`, build descriptors from the rc tools:
   `rc_core::Tool` exposes name/description/schema - map each into the same JSON
   definition shape (anthropic branch) / `wrap` (OpenAI branch).
3. In `execute()`, route their namespace to
   `rc_lifecycle`'s `Executor` (it applies sandbox + timeout + metrics). Keep the
   security gate in front: authorize first, executor second.
4. Guard with a config flag (new `rc_tools.enabled` section) so the default 20-tool
   surface stays stable for prompt caching.

## Recipe C - add a slash command

1. Server arm in `Hub::run_command` (`crates/server/src/api.rs`, ~line 436): match the
   name, read/write `cfg` (it is `Mutex<Config>`), call `cfg.save()`, return a
   user-facing notice string. Unknown names fall through to
   `Err(format!("unknown command /{other}"))`.
2. Client whitelist in `crates/client-tui/src/app.rs` `send()` (~line 569): add the
   name to the `provider_cmd` `matches!` list so it routes as
   `ClientRequest::Command` instead of a chat message. (Known gap in the tree:
   `/rnmap` and `/settings` exist server-side but are missing from this list, so they
   currently go to the model as text - fix by adding them.)
3. Local-only commands (`new`, `clear`, `panel`, `quit`) instead map to `Cmd::` in the
   second match (~line 588).
4. If the command should also be editable in the Ctrl+P panel, add a catalog row in
   `crates/shared/src/tui_settings.rs` - every panel row writes `tui.<path>` back to
   the brain's config.

## Recipe D - add a provider

- No code: `providers` config map entry or `/customprovider <id> <base-url>
  [openai|anthropic]`.
- Cataloged: append a `Known { id, name, kind, base_url, key_env, needs_key,
  default_model, models }` row to `KNOWN` in `crates/shared/src/catalog.rs` (31 rows
  today; pick `ApiKind::Anthropic` for `/v1/messages` wire, `ApiKind::OpenAi` for
  chat-completions). Keep model lists a superset across any duplicated vendor rows.
- RAG requires the provider to expose an embeddings endpoint
  (`ROMACODE_EMBEDDINGS_MODEL` overrides the model id).

## Recipe D2 - the modeldata seam (per-model official rules)

`crates/shared/modeldata/<provider>/<model>.json` (35 provider folders, v0.8.0)
is the official profile library every selected model follows: context window,
max output, param ranges, wire rules, endpoints, pricing, sources. Registry =
`crates/shared/src/modeldata.rs` (`profile_for` is TOTAL - exact/normalized/
family/name-shape/_provider/_default). When adding a model: edit the dataset in
`scripts/gen_modeldata.py`, rerun it (it regenerates the JSONs AND
`src/modeldata_gen.rs`), keep numbers sourced or flagged `unverified_fields`.
Request shaping lives in `agent.rs::anthropic_body` / `openai_body` and the
langchain builder - both engines clamp through `profile_for`, keep them in
sync. TUI annotation is render-time in `palette.rs` (never touch the raw id
string; selection must keep saving exact ids).

## Recipe E - tune the loop

Everything is a config key under `agent` / `model_params` / top level (full key map in
`references/architecture-map.md`): `engine` (native | langchain), `default_mode`,
`max_tool_rounds` (200, clamp 10 000), `tool_timeout_secs`, `max_tool_output_bytes`,
`auto_compact` + `compact_threshold_pct`, `context_window`, `system_prompt`,
`system_prompt_append`, and `instruction_files` (ROMACODE.md, AGENTS.md, CLAUDE.md are
auto-loaded from the project). Project-level behavior overrides go in the project's
`ROMACODE.md`.

## Verify before you ship

1. `cargo build --workspace --locked` - zero errors; `cargo test --workspace --locked`
   - the rnmap engine tests (15) and the approval end-to-end test in `api.rs` must stay
   green.
2. `romacode-server --print-config` shows your new keys merged with defaults.
3. Run the brain (`romacode-server serve --cwd /tmp/proj`) and drive one turn over
   `scripts/e2e_ws.py` or the TUI: the new tool must appear in the model's tool list,
   execute, and stream `ToolStart`/`ToolEnd`.
4. Re-check the gate: unknown tool names still refuse with
   `tool <name> is unavailable`.
