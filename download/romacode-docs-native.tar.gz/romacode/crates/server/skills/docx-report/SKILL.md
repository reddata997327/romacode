---
name: docx-report
description: Produce a professional Word (.docx) report with python-docx - styled cover, table of contents, numbered sections, tables with header shading, figure captions and a final postcheck (open the file again, verify headings/tables/images, search for leftover placeholders). Use when the user asks for a report, catalog, comparison or any Word deliverable.
---

# DOCX Report Production

Deliverable rule: a report lands as a real `.docx` in the download directory
plus a PDF render for visual verification. Never finish by printing text in
the chat.

## Pipeline

1. **Design first.** Fix audience, depth (catalog vs summary), length and what
   must stay out (e.g. secrets — keep config keys, drop URLs and client ids).
2. **Content from measurements, not memory.** Extract facts with a script
   (`rg`/walk the tree), print intermediate results, re-check every number
   that goes into the document against that output.
3. **Generate with python-docx** (pip module `python-docx`):
   * Styles: set `Normal` font (e.g. Calibri 10.5pt) and heading styles once;
     never inline-format every run.
   * Cover: title, subtitle, date, version block — then a page break.
   * TOC: insert a real TOC field (`w:fldSimple` `TOC \o "1-3" \h \z \u`) so
     Word populates it; LibreOffice renders it on `--convert-to pdf`.
   * Sections: `Heading 1` per chapter, `Heading 2` per subsection; body
     paragraphs of 3-5 sentences, 150+ words per section.
   * Tables: one `Table` per dataset, bold header row with shading
     (`w:shd` fill), `Table Grid` style, no empty cells — use `n/a`.
   * Figures: add picture, then `Caption`-styled paragraph under it.
4. **Postprocess** (`postprocess_docx.py` pattern):
   * de-duplicate the first TOC entry if the field renders twice;
   * widen table columns that break words badly (`autofit True`, set column
     widths explicitly);
   * replace any `【...】` placeholders or fail the build.
5. **Postcheck (must pass before delivery).** Reopen with python-docx:
   print heading list, table count, image count; `rg` the docx XML for
   `TODO`, `XXX`, `【`, `placeholder`. Then
   `soffice --headless --convert-to pdf` and `pdftoppm -r 60` every page,
   look at the JPEGs: repeated sections, broken tables, blank pages or
   markdown symbols (`**`, `#`, `|---|`) in rendered text fail the run — fix
   the generator, regenerate, re-verify. Keep the PDF next to the docx.

## Sizing rules

* Catalog depth: one table row per item, one chapter per subsystem; the
  Claude Code extraction report (17 pages, 40+ tools, 8 subsystems) is the
  reference shape.
* Length bands excluding cover/TOC/appendix: short ~500 words, standard
  ~1,500, catalog 3,000+.
* Every explicit user requirement (part, deliverable, length, naming,
  audience) maps to a section before writing starts.
