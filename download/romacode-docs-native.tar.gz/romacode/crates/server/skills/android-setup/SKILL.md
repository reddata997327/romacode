---
name: android-setup
description: Bootstrap a working Android target from a bare machine - discover or install the SDK platform-tools, create an AVD with a system image, boot the emulator detached and wait for full boot completion, all through the android_setup tool (status/doctor/create_avd/boot/wait) instead of giving up when no device is online. Use whenever the user asks to turn on, start, build or set up Android and adb shows no target, or before any android_* tool on a fresh host.
---

# Android Setup Playbook

Never conclude "no device, cannot power on" while the host has no Android
environment — set one up. Every step maps to the `android_setup` tool, which
works without a live device and needs no `android.serial`.

## Order of operations

1. **`android_setup {"action": "status"}`** — one call, full audit:
   adb path resolution, SDK root (ANDROID_HOME, ANDROID_SDK_ROOT, platform
   defaults like `~/Android/Sdk`), emulator/avdmanager/sdkmanager presence,
   existing AVDs, installed system images, online devices, KVM verdict.
   Read this JSON before anything else.
2. **`android_setup {"action": "doctor"}`** — when status reports gaps, doctor
   returns the exact host commands to close them (apt/dnf/brew lines,
   sdkmanager license acceptance, KVM group fix). Show the plan, then run the
   pieces through Bash.
3. **`android_setup {"action": "create_avd", "image": "system-images;android-34;google_apis;x86_64"}`**
   — installs the system image through sdkmanager when missing (this can take
   minutes; the tool caps the wait and reports progress), then
   `avdmanager create avd -n <name> -k <image> -d pixel_5 --force`.
   Omit `name` for the default `romacode`.
4. **`android_setup {"action": "boot", "name": "<avd>"}`** — spawns
   `emulator -avd <name> -no-snapshot-load -no-boot-anim -gpu auto` DETACHED
   (survives the tool call), then polls `adb wait-for-device` +
   `sys.boot_completed` up to 300 s. Returns the adb serial when green.
5. **`android_setup {"action": "wait", "timeout": 120}`** — re-check only.
6. **Hand over to the device tools.** Only now call `android_device` first,
   then `android_shell`, `android_install`, `android_screenshot`, ...
   (the standard rule: query properties from the device, never fabricate).

## Honest fallbacks

* No KVM (`/dev/kvm` missing or not writable): say so, offer
  `-accel off` boot (slow) or installing the kvm group packages from doctor.
* No emulator binary but platform-tools exist: doctor prints the
  cmdline-tools + emulator install lines; run them, re-run status.
* sdkmanager needs license acceptance: run
  `yes | sdkmanager --licenses` via Bash, retry create_avd.
* Physical device instead of emulator: plug in, enable USB debugging, approve
  the key; `android_setup status` shows it as an online target and the
  playbook ends at step 6.

## What NOT to do

* Do not probe with ad-hoc Bash commands (`emulator -list-avds`,
  `adb devices -l`) when `android_setup status` answers them in one call.
* Do not boot an emulator twice — status already lists online devices.
* Do not claim a device exists until `android_device` returns real properties.
