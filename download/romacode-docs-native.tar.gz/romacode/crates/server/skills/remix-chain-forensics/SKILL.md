---
name: remix-chain-forensics
description: Live Ethereum mainnet investigation with the native rrx toolchain — endpoint health, blocks, tx replay with gas delta, call-tree traces, ENS/tokens/logs, arbitrary view calls at any block, verified sources, locally-verified MPT state proofs, forks, and the fake-asset detection stack. Evidence discipline included.
---

# remix-chain-forensics: on-chain investigation

Every command here is a REAL mainnet read through the built-in endpoint list
(live probing + automatic failover). `--rpc <url>` overrides per call;
`remix.rpc` in the config overrides globally (passed as `RRX_RPC`). No
simulation anywhere. Evidence discipline: the final answer cites the block
numbers, proof verdicts, and Δ% figures the tools returned — never "the
node said".

## 1. Establish ground truth

- `remix net` — probe ALL endpoints live (latency, head block, client).
  Run this first when numbers look stale or two calls disagree.
- `remix chain` — client, head block, base fee, priority fees.
- `remix chains [slug] [--json]` — the multi-chain network list.
- `remix block <n|latest|finalized>` — one block summary.
- `remix gasprice` — the current fee landscape.

## 2. Transactions

- `remix tx 0x<hash>` — full tx + receipt report (status, gas, logs).
- `remix trace 0x<hash>` — call-tree trace (callTracer): who called whom
  with what value.
- `remix debugtx 0x<hash> [--max-steps n] [--top n]` — **the flagship**.
  Fetches tx + receipt + header, reads the PRE-tx state over RPC, executes
  the calldata in the built-in EVM at the correct fork spec (Istanbul…
  Cancun by real activation heights), then compares:
  `chain SUCCESS 45,160 gas | replay SUCCESS 46,428 gas [Δ 2.81%]` plus an
  opcode gas profile and step trace. Interpretation: a small Δ is normal
  (state growth, warm/cold slots); a **big Δ% is a finding** — report it
  with the opcode table, do not silently average it away.

## 3. Accounts, names, tokens

- `remix ens <name>` / `remix ens --reverse <addr>` — real registry
  resolution, forward and reverse. Resolve names **before** addresses so
  reports stay readable.
- `remix account <ADDRESS|ens.name>` — balance / nonce / code.
- `remix token <addr> [--holder <h>]` — ERC-20/721/1155 inspector
  (decimals, supply, holder balances).
- `remix ethcall <to> <fn> [args…] [--types "address,uint256"]
  [--returns "uint256"] [--block n]` — arbitrary view call **at any block**;
  the `--block` switch is how you answer "what did this look like before
  the incident".

## 4. Events and history

- `remix logs --address <a> [--topic0 "Transfer(address,address,uint256)"]
  [--from latest] [--to …]` — filtered event history.
- Compose topic hashes from signatures when only the event name is known:
  `remix utils selector "Event(types)"`, `remix utils keccak <hex>`,
  `remix utils namehash <name>`, `remix utils unit <wei|gwei|eth>`.
- `remix index` — index recent blocks into `rrx-index.json` for quick scans.

## 5. Proofs and sources — verify, don't trust

- `remix proof <addr> [--slot n] [--block tag]` — account + storage MPT
  proofs, RLP-decoded and Merkle-walked locally against the block
  stateRoot. `PROOF VALID ✓ … slot 0x1 = 84298736466239384` — a lying node
  cannot pass. Use it whenever a node's claim matters: balances,
  approvals, critical storage slots.
- `remix sources <addr> [--chain 1]` — fetch VERIFIED sources
  (Sourcify → Etherscan V2) before judging what a contract does.
- `remix bytediff <addr> <Contract>` — on-chain bytecode vs a local build;
  catches proxy/implementation swaps and quietly-redeployed lookalikes.

## 6. Fake-asset stack (detection only)

- `remix fakeasset registry [--verify-live]` — the canonical USDT/USDC/
  WETH(WBNB) table per chain (live symbol/decimals check with
  `--verify-live`); rebrand aliases included (e.g. `USD₮0` on L2s).
- `remix fakeasset registry --compare 0x<addr> --chain ethereum` — verdict
  `CLONE / REAL / UNKNOWN` from ticker, decimals, name, and live supply
  comparison.
- `remix fakeasset variants|audit|pending` — known fake variants, honeypot
  auditing, pending detections. `remix fakeasset source|compile|verify` —
  inspect the teaching demo. The `deploy`/`flasher` sub-actions are demo
  tooling and count as chain writes (`remix.allow_chain_writes=true`
  required). **Scope note:** this stack is the detection side — it finds
  clones, recognizes honeypots, fact-checks screenshots; it does not
  produce scam material.
- `remix wildtoken source|compile|demo` — the teaching demo token.

## 7. Local forks and EVM internals

- `remix fork <usdt|usdc|weth|dai|0x…> [--chain] [--block]` — preload real
  mainnet state into the built-in EVM for offline experimentation.
- `remix blob` — blob-carrying txs (4844); `remix verkle` — verkle trees;
  `remix build-block` — build a block locally; `remix precompiles 1..9` —
  precompile behavior.

## Investigation playbook (typical order)

```text
remix_status                        # doctor first, every session
remix net && remix chain            # ground truth
remix ens victim.eth                # resolve names first
remix tx 0x<hash> && remix trace 0x<hash>
remix debugtx 0x<hash> --max-steps 20 --top 10   # replay + Δ%
remix account 0x<addr> && remix token 0x<tok> --holder 0x<addr>
remix ethcall 0x<tok> allowance(address,address) --types "address,address" \
      --returns "uint256" --block <pre-incident>
remix proof 0x<tok> --slot 1        # locally verified storage claim
remix sources 0x<tok>               # verified source before judgment
remix fakeasset registry --compare 0x<tok> --chain ethereum
```

## Usage

Activate for "look into this tx/address/token", "is this token a scam",
"prove this balance", "what did this transaction actually do", gas/fee
questions, or any mainnet state question. Cite endpoint evidence (block
numbers, proof verdicts, Δ%) in the final answer. Master reference:
`remix-ethereum`; authoring loop: `remix-contract-dev`.
